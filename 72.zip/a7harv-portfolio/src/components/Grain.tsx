export function Grain() {
  return <div className="grain-overlay" />;
}
